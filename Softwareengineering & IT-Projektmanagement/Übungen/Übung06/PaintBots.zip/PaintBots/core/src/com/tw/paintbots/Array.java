package com.tw.paintbots;

/** This is a utility class that helps to create arrays. */
public class Array {
  // --------------------------------------------------------------- //
  public static int[] of(int... elements) {
    return elements;
  }

  // --------------------------------------------------------------- //
  public static String[] of(String... elements) {
    return elements;
  }

  // --------------------------------------------------------------- //
  public static float[] of(float... elements) {
    return elements;
  }
}
