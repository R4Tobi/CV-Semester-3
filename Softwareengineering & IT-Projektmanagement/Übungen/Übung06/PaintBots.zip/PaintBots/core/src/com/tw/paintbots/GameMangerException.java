package com.tw.paintbots;

public class GameMangerException extends Exception {
  public GameMangerException(String message) {
    super(message);
  }
}
