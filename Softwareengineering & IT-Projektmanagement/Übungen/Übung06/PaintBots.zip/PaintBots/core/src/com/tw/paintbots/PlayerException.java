package com.tw.paintbots;

public class PlayerException extends Exception {
  public PlayerException(String message) {
    super(message);
  }
}
